﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Clase12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btn_enviar_Click(object sender, EventArgs e)
        {
            List<string> nombres = new List<string>();
            List<string> lastname = new List<string>();
            string nombre = txtNombre.Text;
            nombres.Add(nombre);
            string apellidos = txtApellido.Text;
            lastname.Add(apellidos);
            string identificacion = txtDNI.Text;
            string email = txtEmail.Text;

            if(Regex.IsMatch(nombre, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show($"{nombre} es válido.");
            } else
            {
                MessageBox.Show($"{nombre} contiene números.");
            }
            if (Regex.IsMatch(apellidos, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show($"{apellidos} es válido.");
            }
            else
            {
                MessageBox.Show($"{apellidos} contiene números.");
            }
            if (Regex.IsMatch(identificacion, @"^\d+$"))
            {
                MessageBox.Show($"{identificacion} es válido.");
            }
            else
            {
                MessageBox.Show($"{identificacion} contiene letras.\n" +
                    $"Deben ser números");
            }
            if (Regex.IsMatch(email, @"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$"))
            {
                MessageBox.Show($"{email} es válido.");
            }
            else
            {
                MessageBox.Show($"{email} correo no válido.");
            }

            if(nombre != "" || apellidos != "" || identificacion != "" || email != "")
            {
                txtNombre.Text = "";
                txtApellido.Text = "";
                txtDNI.Text = "";
                txtEmail.Text = "";

                MessageBox.Show("Los datos se han enviado correctamente.");
            } else
            {
                MessageBox.Show("Por favor, corrige los errores en el formulario");
            }

            /*foreach (string name in nombres)
            {
                if (Regex.IsMatch(name, @"^[a-zA-Z]+$"))
                {
                    MessageBox.Show($"{name} es válido.");
                }
                else
                {
                    MessageBox.Show($"{name} contiene números.");
                }
            }
            foreach (string lastnames in lastname)
            {
                if (Regex.IsMatch(lastnames, @"^[a-zA-Z]+$"))
                {
                    MessageBox.Show($"{lastnames} es válido.");
                }
                else
                {
                    MessageBox.Show($"{lastnames} contiene números.");
                }
            }*/

        }
    }
}
